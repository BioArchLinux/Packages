library(testthat)
library(ankiR)

test_check("ankiR")
