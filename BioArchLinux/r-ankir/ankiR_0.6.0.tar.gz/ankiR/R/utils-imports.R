#' @importFrom stats aggregate ave chisq.test cor median qnorm setNames
#' @importFrom utils head tail
NULL
